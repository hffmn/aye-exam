<?php $__env->startSection('title'); ?>Список заказов<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <h1 class="text-center mt-2">Список заказов</h1>
    <?php if(isset($data)): ?>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">Название</th>
                <th scope="col">Цена</th>
                <th scope="col">Статус</th>
                <th scope="col">Дата</th>
                <?php if(\Illuminate\Support\Facades\Auth::user()->role == 1): ?>
                    <th scope="col">ФИО Заказчика</th>
                    <th scope="col">Завершить заказ</th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $service = \App\Service::find($ticket->service_id);
                    $user = \App\User::find($ticket->user_id);
                ?>
                <tr>
                    <td><?php echo e($service->name); ?></td>
                    <td><?php echo e($service->cost); ?></td>
                    <td><?php echo e($ticket->status == 0 ? 'Выполняется' : 'Готово'); ?></td>
                    <td><?php echo e($ticket->created_at); ?></td>
                    <?php if(\Illuminate\Support\Facades\Auth::user()->role == 1 && $ticket->status != 1): ?>
                        <td><?php echo e($user->fio); ?></td>
                        <td>
                            <a href="<?php echo e(route('ticket-close', $ticket->id)); ?>" class="btn btn-success">Завершить заказ</a>
                        </td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <h2>Список заказов пуст</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\xmpp\htdocs\laravel\resources\views/ticket/main.blade.php ENDPATH**/ ?>