<?php $__env->startSection('title'); ?>Добавить услугу<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Добавить услугу</h1>
    <form action="<?php echo e(route('service-add')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Комната</label>
            <input
                class="form-control"
                type="text"
                name="name"
                id="name"
                placeholder="Введите номер комнаты"
                required
            >
        </div>

        <div class="form-group">
            <label for="cost">Цена</label>
            <input
                class="form-control"
                type="text"
                name="cost"
                id="cost"
                placeholder="Укажите цену в рублях"
                required
            >
        </div>

        <button type="submit" class="btn btn-primary">Добавить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\xmpp\htdocs\laravel\resources\views/service/main.blade.php ENDPATH**/ ?>