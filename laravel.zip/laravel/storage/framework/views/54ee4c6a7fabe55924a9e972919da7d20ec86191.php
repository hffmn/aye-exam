<?php $__env->startSection('title'); ?>Главная страница<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-center mt-2">Выбор комнаты</h1>
    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card m-3" style="width: 18rem; display: inline-block;">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($service->name); ?></h5>
                <p class="card-text">Цена: <b><?php echo e($service->cost); ?> руб.</b></p>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('ticket-create', $service->id)); ?>" class="btn btn-success mb-3">Арендовать комнату</a><br>
                    <?php if(\Illuminate\Support\Facades\Auth::user()->role == 1): ?>
                        <a href="<?php echo e(route('service-update', $service->id)); ?>" class="btn btn-info mb-3">Изменить</a><br>
                        <a href="<?php echo e(route('service-delete', $service->id)); ?>" class="btn btn-danger">Удалить</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2>Комнаты отсутствуют</h2>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\xmpp\htdocs\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>