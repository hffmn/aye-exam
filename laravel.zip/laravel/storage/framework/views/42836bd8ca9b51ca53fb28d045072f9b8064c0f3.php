<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<nav class="navbar navbar-light bg-primary p-3">
    <div class="container">
        <div class="d-flex">
            <a href="<?php echo e(route('home')); ?>" class="nav-item">
                <span class="nav-link">Каталог комнат</span>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(\Illuminate\Support\Facades\Auth::user()->role == 1): ?>
                    <a href="<?php echo e(route('service-add')); ?>" class="nav-item">
                        <span class="nav-link">Добавить комнату</span>
                    </a>
                <?php endif; ?>

                <a href="<?php echo e(route('ticket-page')); ?>" class="nav-item">
                    <span class="nav-link">Список резервов</span>
                </a>
            <?php endif; ?>
        </div>

        <div class="d-flex">
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="nav-item">
                    <span class="nav-link">Авторизация</span>
                </a>
                <a href="<?php echo e(route('register')); ?>" class="nav-item">
                    <span class="nav-link">Регистрация</span>
                </a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <div class="nav-item">
                    <span class="text-white" style="padding: .5rem 1rem;display: block"><?php echo e(Auth::user()->getFullname()); ?></span>
                </div>
                <a href="<?php echo e(route('home')); ?>" class="nav-item">
                        <span class="nav-link"
                              onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                        >Выйти</span>
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none">
    <?php echo csrf_field(); ?>
</form>

<div class="container">
    <?php echo $__env->make('inc.messeges', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
<?php /**PATH D:\xampp\xmpp\htdocs\laravel\resources\views/layout/app.blade.php ENDPATH**/ ?>